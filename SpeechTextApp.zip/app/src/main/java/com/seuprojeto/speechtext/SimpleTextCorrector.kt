package com.seuprojeto.speechtext

object SimpleTextCorrector {
    fun correctText(input: String): String {
        var output = input
        val corrections = mapOf(
            "pecado" to "obrigado",
            "será" to "será",
            "maca" to "marca",
            "feijão" to "reunião"
        )
        corrections.forEach { (wrong, correct) ->
            output = output.replace(wrong, correct, ignoreCase = true)
        }
        output = output.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
        return output
    }
}